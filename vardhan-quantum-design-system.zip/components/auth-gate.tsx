'use client'

import { useEffect, useState, type FormEvent, type ReactNode } from 'react'
import { LogOut, ShieldCheck } from 'lucide-react'
import { AccessPanel } from '@/components/access-panel'
import { authAdapter, backendIntegrationStatus, type AuthSession } from '@/lib/vardhan-auth'

export function AuthGate({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AuthSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [signedOut, setSignedOut] = useState(false)
  const [accessOpen, setAccessOpen] = useState(false)
  useEffect(() => { let mounted = true; authAdapter.getSession().then(async value => { const refreshed = value ? await authAdapter.refreshSession(value) : null; if (mounted) { setSession(refreshed); setLoading(false) } }); return () => { mounted = false } }, [])
  if (loading) return <div className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">Checking Vardhan session…</div>
  if (!session || signedOut) return <Login onSignedIn={value => { setSession(value); setSignedOut(false) }} />
  return <div className="relative"><div className="fixed bottom-4 left-4 z-20 flex items-center gap-3 rounded-md border border-border bg-card px-3 py-2 text-[10px] shadow-xl"><span className="size-1.5 rounded-full bg-amber-300" /> <button className="text-left text-muted-foreground hover:text-foreground" onClick={() => setAccessOpen(true)}>Development adapter · backend authorization not connected</button><button className="text-foreground hover:text-blue-300" onClick={async () => { await authAdapter.signOut(); setSignedOut(true) }} aria-label="Sign out"><LogOut size={13} /></button></div>{children}{accessOpen && <AccessPanel close={() => setAccessOpen(false)} />}</div>
}

function Login({ onSignedIn }: { onSignedIn: (session: AuthSession) => void }) {
  const [email, setEmail] = useState('operator@vardhan.local'); const [password, setPassword] = useState(''); const [error, setError] = useState('')
  async function submit(event: FormEvent) { event.preventDefault(); if (!email || !password) { setError('Enter credentials to continue.'); return } onSignedIn(await authAdapter.signIn(email, password)) }
  return <main className="flex min-h-screen items-center justify-center bg-background p-6"><section className="w-full max-w-md rounded-lg border border-border bg-card p-7 shadow-2xl"><div className="mb-8 flex items-center gap-3"><div className="flex size-10 items-center justify-center rounded-md bg-blue-500/15 text-blue-300"><ShieldCheck size={21} /></div><div><p className="text-sm font-semibold tracking-[.18em]">VARDHAN</p><p className="mono text-[9px] text-muted-foreground">QUANTUM CONTROL PLANE</p></div></div><p className="mono mb-2 text-[10px] uppercase tracking-[.16em] text-blue-300">Secure access</p><h1 className="text-2xl font-semibold">Sign in to the control plane</h1><p className="mt-2 text-xs leading-5 text-muted-foreground">Identity, session issuance, and authorization are owned by the Vardhan backend.</p><div className="mt-5 rounded border border-amber-300/20 bg-amber-300/5 p-3 text-xs leading-5 text-amber-100">Preview mode uses an isolated development adapter. No credentials are sent or stored.</div><form onSubmit={submit} className="mt-6 flex flex-col gap-4"><label className="flex flex-col gap-2 text-xs"><span className="text-muted-foreground">Email</span><input className="h-10 rounded border border-border bg-background px-3 outline-none focus:border-blue-300" value={email} onChange={event => setEmail(event.target.value)} type="email" /></label><label className="flex flex-col gap-2 text-xs"><span className="text-muted-foreground">Password</span><input className="h-10 rounded border border-border bg-background px-3 outline-none focus:border-blue-300" value={password} onChange={event => setPassword(event.target.value)} type="password" /></label>{error && <p role="alert" className="text-xs text-rose-300">{error}</p>}<button className="h-10 rounded bg-blue-500 px-4 text-xs font-semibold text-white hover:bg-blue-400">Continue</button></form><p className="mt-6 border-t border-border pt-4 text-[10px] text-muted-foreground">{backendIntegrationStatus.note}</p></section></main>
}
