export type ViewKey = 'overview' | 'operations' | 'quantum' | 'infrastructure' | 'reliability' | 'evidence' | 'decisions' | 'login-activity' | 'active-sessions' | 'admin'
export type Tone = 'good' | 'warn' | 'critical' | 'info' | 'neutral'
export const navGroups = [
  { label: 'Control plane', items: [{ key: 'overview', label: 'Overview', icon: 'LayoutDashboard' }, { key: 'operations', label: 'Security operations', icon: 'ShieldAlert' }, { key: 'quantum', label: 'Quantum security', icon: 'Atom' }] },
  { label: 'Systems', items: [{ key: 'infrastructure', label: 'Infrastructure', icon: 'Network' }, { key: 'reliability', label: 'Reliability', icon: 'Activity' }] },
  { label: 'Assurance', items: [{ key: 'evidence', label: 'Evidence explorer', icon: 'FileSearch' }, { key: 'decisions', label: 'AI decisions', icon: 'GitPullRequest' }] },
  { label: 'Identity', items: [{ key: 'login-activity', label: 'Login activity', icon: 'History' }, { key: 'active-sessions', label: 'Active sessions', icon: 'MonitorSmartphone' }] },
  { label: 'Manage', items: [{ key: 'admin', label: 'Administration', icon: 'Settings2' }] },
] as const
export const metrics = [
  { label: 'Assurance posture', value: '87.4%', change: '+2.8%', tone: 'good' as Tone, detail: 'controls evidenced' },
  { label: 'Active material risk', value: '04', change: '2 critical', tone: 'critical' as Tone, detail: 'requires review' },
  { label: 'Crypto coverage', value: '72.1%', change: '+6.4%', tone: 'info' as Tone, detail: 'migration mapped' },
  { label: 'Systems observed', value: '1,284', change: '99.98%', tone: 'good' as Tone, detail: 'telemetry freshness' },
]
export const incidents = [
  { id: 'INC-4021', title: 'Legacy RSA-2048 exposure in payment gateway', severity: 'Critical', tone: 'critical' as Tone, status: 'Investigating', asset: 'payments-prod / gateway-03', age: '18m' },
  { id: 'INC-4018', title: 'Unexpected mTLS certificate rotation', severity: 'High', tone: 'warn' as Tone, status: 'Acknowledged', asset: 'edge-eu-west / ingress', age: '42m' },
  { id: 'INC-4012', title: 'Telemetry gap across archive cluster', severity: 'Medium', tone: 'info' as Tone, status: 'Monitoring', asset: 'archive-prod / cluster-7', age: '2h' },
]
export const activities = [
  { time: '09:42:18', title: 'Control evidence refreshed', detail: 'SOC 2 CC6.1 · 18 sources reconciled', tone: 'good' as Tone },
  { time: '09:38:04', title: 'Risk threshold exceeded', detail: 'RSA-2048 usage detected in payment gateway', tone: 'critical' as Tone },
  { time: '09:21:47', title: 'Change verified', detail: 'mTLS rotation completed for edge-eu-west', tone: 'info' as Tone },
  { time: '08:56:12', title: 'Migration recommendation issued', detail: '3 systems eligible for ML-KEM pilot', tone: 'warn' as Tone },
]
export const evidence = [
  { source: 'Crypto inventory scanner', id: 'EV-88291', type: 'Telemetry', updated: '2m ago', freshness: 'Fresh', tone: 'good' as Tone },
  { source: 'Policy engine / pqc-baseline-01', id: 'EV-88287', type: 'Control', updated: '11m ago', freshness: 'Fresh', tone: 'good' as Tone },
  { source: 'Change record CHG-19304', id: 'EV-88271', type: 'Audit', updated: '43m ago', freshness: 'Recent', tone: 'info' as Tone },
  { source: 'Asset graph / payments-prod', id: 'EV-88144', type: 'Dependency', updated: '3h ago', freshness: 'Stale', tone: 'warn' as Tone },
]
