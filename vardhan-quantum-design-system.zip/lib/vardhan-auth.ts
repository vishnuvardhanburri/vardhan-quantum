export type Role = 'executive' | 'security-operations' | 'quantum-security' | 'sre' | 'engineering' | 'infrastructure' | 'assurance' | 'admin'

export type Permission =
  | 'view:overview'
  | 'view:operations'
  | 'view:quantum'
  | 'view:infrastructure'
  | 'view:reliability'
  | 'view:evidence'
  | 'review:decisions'
  | 'view:login-activity'
  | 'view:active-sessions'
  | 'manage:access'
  | 'manage:sessions'

export type AuditEventType = 'LOGIN_SUCCESS' | 'LOGIN_FAILURE' | 'LOGOUT' | 'SESSION_EXPIRED' | 'SESSION_REVOKED' | 'ROLE_CHANGED' | 'PERMISSION_CHANGED' | 'ACCOUNT_DISABLED'
export type AccountStatus = AuthenticatedUser['status']

export interface AuthenticatedUser { id: string; email: string; displayName: string; role: Role; status: 'active' | 'suspended' | 'pending' }
export interface AuthSession { id: string; user: AuthenticatedUser; issuedAt: string; expiresAt: string; lastSeenAt: string; authSource: 'vardhan-api' | 'development-adapter' }
export interface LoginEvent { id: string; occurredAt: string; outcome: 'success' | 'failure' | 'revoked'; ipAddress: string; userAgent: string; location: string }
export interface ActiveSession { id: string; issuedAt: string; lastSeenAt: string; device: string; location: string; current: boolean; revokedAt?: string }
export interface AuthorizationDecision { allowed: boolean; permission: Permission; reason: string; evaluatedAt: string }

const developmentUser: AuthenticatedUser = { id: 'dev-user-01', email: 'operator@vardhan.local', displayName: 'A. Mehta', role: 'security-operations', status: 'active' }

export interface VardhanAuthAdapter {
  getSession(): Promise<AuthSession | null>
  signIn(email: string, password: string): Promise<AuthSession>
  signOut(): Promise<void>
  refreshSession(session: AuthSession): Promise<AuthSession | null>
  getAccountStatus(session: AuthSession | null): Promise<AccountStatus>
  getLoginActivity(): Promise<LoginEvent[]>
  getActiveSessions(): Promise<ActiveSession[]>
  revokeSession(sessionId: string): Promise<void>
  authorize(permission: Permission, session: AuthSession | null): Promise<AuthorizationDecision>
}

/** Development-only adapter. Replace these calls with the Vardhan API client in production. */
export const developmentAuthAdapter: VardhanAuthAdapter = {
  async getSession() { return { id: 'dev-session-01', user: developmentUser, issuedAt: '2026-09-11T08:00:00Z', expiresAt: '2026-09-11T16:00:00Z', lastSeenAt: '2026-09-11T09:44:02Z', authSource: 'development-adapter' } },
  async signIn(email) { return { id: 'dev-session-01', user: { ...developmentUser, email }, issuedAt: new Date().toISOString(), expiresAt: '2026-09-11T16:00:00Z', lastSeenAt: new Date().toISOString(), authSource: 'development-adapter' } },
  async signOut() {},
  async refreshSession(session) { return new Date(session.expiresAt).getTime() <= Date.now() ? null : { ...session, lastSeenAt: new Date().toISOString() } },
  async getAccountStatus(session) { return session?.user.status ?? 'pending' },
  async getLoginActivity() { return [{ id: 'LOGIN-2041', occurredAt: '2026-09-11T09:41:18Z', outcome: 'success', ipAddress: '10.24.8.19', userAgent: 'Chrome / macOS', location: 'London, GB' }, { id: 'LOGIN-2038', occurredAt: '2026-09-10T18:03:07Z', outcome: 'success', ipAddress: '10.24.8.19', userAgent: 'Safari / iOS', location: 'London, GB' }] },
  async getActiveSessions() { return [{ id: 'SESSION-01', issuedAt: '2026-09-11T08:00:00Z', lastSeenAt: '2026-09-11T09:44:02Z', device: 'Chrome on macOS', location: 'London, GB', current: true }, { id: 'SESSION-00', issuedAt: '2026-09-10T18:03:07Z', lastSeenAt: '2026-09-10T18:44:19Z', device: 'Safari on iPhone', location: 'London, GB', current: false }] },
  async revokeSession() {},
  async authorize(permission, session) { return { allowed: Boolean(session?.user && session.user.status === 'active' && canAccess(session.user.role, permission)), permission, reason: session ? 'Evaluated by development adapter; backend remains authoritative.' : 'No authenticated session.', evaluatedAt: new Date().toISOString() } },
}

export const authAdapter: VardhanAuthAdapter = developmentAuthAdapter

const rolePermissions: Record<Role, Permission[]> = {
  executive: ['view:overview', 'view:evidence'],
  'security-operations': ['view:overview', 'view:operations', 'view:evidence', 'review:decisions', 'view:login-activity', 'view:active-sessions'],
  'quantum-security': ['view:overview', 'view:quantum', 'view:evidence', 'review:decisions'],
  sre: ['view:overview', 'view:infrastructure', 'view:reliability', 'view:evidence'],
  engineering: ['view:overview', 'view:quantum', 'view:infrastructure', 'view:evidence', 'review:decisions'],
  infrastructure: ['view:overview', 'view:infrastructure', 'view:reliability', 'view:evidence'],
  assurance: ['view:overview', 'view:evidence', 'view:login-activity'],
  admin: ['view:overview', 'view:operations', 'view:quantum', 'view:infrastructure', 'view:reliability', 'view:evidence', 'review:decisions', 'view:login-activity', 'view:active-sessions', 'manage:access', 'manage:sessions'],
}

export function canAccess(role: Role, permission: Permission) { return rolePermissions[role].includes(permission) }
export function permissionForView(view: string): Permission { return ({ overview: 'view:overview', operations: 'view:operations', quantum: 'view:quantum', infrastructure: 'view:infrastructure', reliability: 'view:reliability', evidence: 'view:evidence', decisions: 'review:decisions', admin: 'manage:access', 'login-activity': 'view:login-activity', 'active-sessions': 'view:active-sessions' } as Record<string, Permission>)[view] ?? 'view:overview' }

export const backendIntegrationStatus = { connected: false, adapter: 'development-adapter' as const, note: 'No Vardhan API endpoint is configured in this preview.' }
