import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import './globals.css'
import { AuthGate } from '@/components/auth-gate'

export const metadata: Metadata = {
  title: 'Vardhan Quantum | Control Plane',
  description: 'Evidence-led quantum security and operational assurance control plane.',
  generator: 'Vardhan Quantum',
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#080b11',
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><AuthGate>{children}</AuthGate>{process.env.NODE_ENV === 'production' && <Analytics />}</body></html>
}
